//
//  RootViewController.m
//  FF-RN
//
//  Created by Shaoting Zhou on 2017/12/2.
//  Copyright © 2017年 Shaoting Zhou. All rights reserved.
//

#import "RootViewController.h"
#import "RNViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我是iOS原生界面";
    
    
    UIButton * pushRNBtn = [[UIButton alloc]initWithFrame:CGRectMake(50, 100, 200, 50)];
    [pushRNBtn setTitle:@"push到RN界面" forState:(UIControlStateNormal)];
    [pushRNBtn setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
    [pushRNBtn addTarget:self action:@selector(pushRNVC) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:pushRNBtn];
    
    
    // Do any additional setup after loading the view.
}

- (void)pushRNVC{
    RNViewController * rnVC = [[RNViewController alloc]init];
    [self.navigationController pushViewController:rnVC animated:NO];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
