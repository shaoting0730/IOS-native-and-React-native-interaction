//
//  AppDelegate.h
//  iOSRN
//
//  Created by Shaoting Zhou on 2017/12/8.
//  Copyright © 2017年 Shaoting Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

