//
//  STSwift.swift
//  Swift-RN
//
//  Created by Shaoting Zhou on 2017/12/5.
//  Copyright © 2017年 Shaoting Zhou. All rights reserved.
//

import UIKit
@objc(STSwift)

public class STSwift: NSObject {
    @objc func logRN(name:NSString) {
        print("接收传过来的NSString \(name)");
     }
    @objc func logRN(name:NSString,dic:NSDictionary){
        print("接收传过来的NSString+NSDictionary: \(name) \(dic)");
    }
    @objc func logRN(name:NSString,time:NSDate){
        print("接收传过来的NSString+日期: \(name) \(time)");
    }
    
}

