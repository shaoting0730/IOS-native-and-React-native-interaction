//
//  RNViewController.swift
//  Swift-RN
//
//  Created by Shaoting Zhou on 2017/12/5.
//  Copyright © 2017年 Shaoting Zhou. All rights reserved.
//

import UIKit
import React.RCTRootView

class RNViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
     
        let strUrl = "http://localhost:8081/index.bundle?platform=ios&dev=true";
        let jsCodeLocation = URL.init(string: strUrl)
        let rootView = RCTRootView.init(bundleURL: jsCodeLocation, moduleName: "nnn", initialProperties: nil, launchOptions: nil)
        self.view = rootView
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
